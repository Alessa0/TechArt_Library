# StarRail NPR Shader Docs

The documentation for [StarRailNPRShader](https://github.com/stalomeow/StarRailNPRShader).
