# Skin-SSS-LUT-Generator for Unity

  PreIntegrate Skin SSS LUT Generator for Unity.
  
  <div align=center><img src="https://user-images.githubusercontent.com/89976115/223177908-90b99e50-567e-49d6-bff5-754945c0ba8d.gif" width="50%" alt="Homework0"></div>
  
# Learn More

  ShaderToy: https://www.shadertoy.com/view/mstGWs
  
  Blog:https://tajourney.games/6465/
 
 ## Usage
 
Tools > SkinSSSLUTGenerator.
Make sure baked Texture first.
 
 ## Reference

 <!-- wp:paragraph -->
<p>1.<a href="https://therealmjp.github.io/posts/sss-intro/">https://therealmjp.github.io/posts/sss-intro/</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>2.<a href="https://developer.nvidia.com/gpugems/gpugems3/part-iii-rendering/chapter-14-advanced-techniques-realistic-real-time-skin">https://developer.nvidia.com/gpugems/gpugems3/part-iii-rendering/chapter-14-advanced-techniques-realistic-real-time-skin</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>3.<a href="https://github.com/codewings/PreIntegrated-Skin">https://github.com/codewings/PreIntegrated-Skin</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>4.<a href="https://www.slideshare.net/leegoonz/penner-preintegrated-skin-rendering-siggraph-2011-advances-in-realtime-rendering-course">https://www.slideshare.net/leegoonz/penner-preintegrated-skin-rendering-siggraph-2011-advances-in-realtime-rendering-course</a></p>
<!-- /wp:paragraph -->
